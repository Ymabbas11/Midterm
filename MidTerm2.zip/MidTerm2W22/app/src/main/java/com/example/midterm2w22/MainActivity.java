package com.example.midterm2w22;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements FragmentA.OnFragmentInteractionListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onFragmentInteraction(int position) {
        Log.d("TAGA", "Index in Main = " + position);

        FragmentManager FragManager = getSupportFragmentManager();
        FragmentB frag2 = (FragmentB) FragManager.findFragmentById(R.id.FragB);

    }



}